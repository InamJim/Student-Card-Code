function toggleDropdown() {
    document.querySelector(".dropdown-content").classList.toggle("show");
}
function toggleMenu() {
    document.getElementById("dropdown").classList.toggle("show");
}

document.getElementById('card-application-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const fullName = document.getElementById('fullName').value;
    const studentId = document.getElementById('studentId').value;
    const email = document.getElementById('email').value;
    const course = document.getElementById('course').value;

    if (!fullName || !studentId || !email || !course) {
        alert('Please fill out all required fields.');
        return;
    }

    alert(`Application submitted successfully for ${fullName}`);
    document.getElementById('card-application-form').reset();
});

        // JavaScript for form validation and redirect
        document.getElementById('loginForm').addEventListener('submit', function (e) {
            e.preventDefault();  // Prevent the form from submitting by default

            // Get the values entered in the form
            const name = document.getElementById('name').value;
            const surname = document.getElementById('surname').value;
            const studentNumber = document.getElementById('student-number').value;
            const password = document.getElementById('password').value;

            // Dummy validation - replace with your own logic
            const validStudentNumber = '123456';
            const validPassword = 'password123';

            if (studentNumber === validStudentNumber && password === validPassword) {
                window.location.href = 'application.html'; // Redirect to application page
            } else {
                document.getElementById('error-message').textContent = 'Invalid student number or password';
            }
        });
    