function toggleDropdown() {
    document.querySelector(".dropdown-content").classList.toggle("show");
}
